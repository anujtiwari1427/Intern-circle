# InternCircle Project 04 — First Machine Learning Classifier

## Project
Train and evaluate a Decision Tree Classifier to predict Titanic passenger survival.

## Files
- `Project_04_Titanic_Classifier.ipynb` — complete executable notebook.
- `Project_04_Results_and_Limitations.pdf` — short write-up template. Fill in actual metrics after running the notebook.

## Features and target
- Target: `survived`
- Features: `pclass`, `sex`, `age`, `fare`
- `sex` encoding: female=1, male=0

## Method
- Drop rows missing any selected field.
- Train/test split: 80/20, random_state=42, stratify=y.
- Baseline: majority class from training labels, evaluated on test labels.
- Model: DecisionTreeClassifier(max_depth=4, random_state=42).
- Evaluation: accuracy, confusion matrix, classification report.
- Overfitting check: compare train and test accuracy for max_depth 1 through 12.
- Interpretability: feature importance and plotted decision tree.

## Run
Install packages:
`pip install pandas numpy matplotlib seaborn scikit-learn jupyter`

Open the notebook in Jupyter or Google Colab and run all cells. The Seaborn Titanic dataset may require internet access on first load.

## Before submitting
1. Run all notebook cells.
2. Confirm the notebook shows outputs.
3. Copy actual accuracy, confusion matrix, most important feature, and best depth into the PDF brief.
4. Share the notebook and write-up links with viewer access as required by InternCircle.

## Limitation
This is a small historical teaching dataset. It is not appropriate for real-world decisions about people.
