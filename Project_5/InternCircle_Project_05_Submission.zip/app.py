import os
import joblib
import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Titanic Survival Predictor",
    page_icon="🚢",
    layout="centered"
)

st.title("🚢 Titanic Survival Predictor")
st.write(
    "Enter passenger details to see the prediction from a Decision Tree "
    "trained on the historical Titanic teaching dataset."
)

@st.cache_resource
def load_model():
    """Load the saved model once and cache it."""
    artifact = joblib.load("model.joblib")
    if isinstance(artifact, dict) and "model" in artifact:
        return artifact["model"], artifact.get(
            "features", ["pclass", "sex", "age", "fare"]
        )
    # Backward compatibility if only the estimator was saved.
    return artifact, ["pclass", "sex", "age", "fare"]

with st.sidebar:
    st.header("Passenger details")
    pclass = st.selectbox("Ticket class", [1, 2, 3], index=2)
    sex_label = st.radio("Sex", ["female", "male"], horizontal=True)
    age = st.slider("Age", min_value=1, max_value=80, value=30)
    fare = st.slider("Fare paid", min_value=0.0, max_value=500.0,
                     value=30.0, step=1.0)

st.caption("This is an educational demonstration using historical data, not advice.")

if st.button("Predict survival", type="primary", use_container_width=True):
    if not os.path.exists("model.joblib"):
        st.error(
            "The model file is missing. Run `python train_model.py` first "
            "to create model.joblib."
        )
    else:
        try:
            model, features = load_model()
            row = pd.DataFrame(
                [[pclass, 1 if sex_label == "female" else 0, age, fare]],
                columns=features
            )
            prediction = int(model.predict(row)[0])

            if hasattr(model, "predict_proba"):
                probability = float(model.predict_proba(row)[0][1])
            else:
                probability = None

            if prediction == 1:
                st.success("Model prediction: Survived")
            else:
                st.warning("Model prediction: Did not survive")

            if probability is not None:
                st.metric(
                    "Estimated survival probability",
                    f"{probability:.1%}"
                )
                st.progress(max(0.0, min(1.0, probability)))

            st.caption(
                "The prediction reflects patterns in a small historical "
                "dataset. It is not a reliable statement about any person."
            )
        except FileNotFoundError:
            st.error("Model file not found. Train and save the model first.")
        except (ValueError, KeyError) as exc:
            st.error(f"Input or model feature problem: {exc}")
        except Exception as exc:
            st.error(f"Could not generate a prediction: {exc}")
