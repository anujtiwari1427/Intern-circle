# InternCircle Project 05 — Streamlit Interactive ML Web App

## Project overview
This project wraps the Titanic Decision Tree classifier from Project 04 in an interactive Streamlit app. Users can select ticket class and sex, set age and fare, and request a prediction with an estimated survival probability.

## Project files
- `app.py` — Streamlit user interface and interactive prediction.
- `train_model.py` — trains the Decision Tree model and saves `model.joblib`.
- `requirements.txt` — Python dependencies.
- `README.md` — setup and deployment instructions.

## Step 1: Create and activate an environment (recommended)
```bash
python -m venv .venv
```
Windows:
```bash
.venv\Scripts\activate
```
macOS/Linux:
```bash
source .venv/bin/activate
```

## Step 2: Install dependencies
```bash
pip install -r requirements.txt
```

## Step 3: Train and save the model
```bash
python train_model.py
```
This downloads the Seaborn Titanic teaching dataset (internet may be required on first run), trains a `DecisionTreeClassifier(max_depth=4, random_state=42)`, prints test metrics, and creates `model.joblib`.

## Step 4: Run the Streamlit app
```bash
streamlit run app.py
```
Open the local URL printed in the terminal (usually http://localhost:8501).

## Step 5: Push to GitHub
Create a repository and upload:
- `app.py`
- `train_model.py`
- `requirements.txt`
- `README.md`

For Streamlit Community Cloud, first ensure `model.joblib` is available to the deployed app. You can generate it locally with `python train_model.py` and include it in the repository if your repository policy permits binary model files. Alternatively, adapt the app to train/download the artifact during deployment. Do not commit private data or secrets.

## Step 6: Deploy on Streamlit Community Cloud
1. Sign in at https://share.streamlit.io/ using GitHub.
2. Select **Create app** and choose your repository and branch.
3. Set the main file path to `app.py`.
4. Deploy and wait for the build to finish.
5. Open the public app URL and test the controls on a phone.

## Submission checklist
The learner guide asks for:
- A link to the deployed app.
- A link to the GitHub repository.
- A screenshot of a prediction.

These links and the screenshot must be created after you run and deploy the project. They are not fabricated in this package.

## Important notes
- Feature order is preserved as `pclass`, `sex`, `age`, `fare`.
- `sex` is encoded as female=1 and male=0, matching the training code.
- The app caches the loaded model with `st.cache_resource`.
- The app shows a friendly message if `model.joblib` is missing.
- This is an educational example based on a historical dataset, not advice or a real-world prediction tool.
