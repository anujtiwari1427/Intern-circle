"""
Train the Titanic Decision Tree model used by the Streamlit app.
Run this script once before starting app.py.
"""
import joblib
import pandas as pd
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

FEATURES = ["pclass", "sex", "age", "fare"]
TARGET = "survived"

def main():
    # The Seaborn Titanic dataset may require internet access on first download.
    df = sns.load_dataset("titanic")
    df = df[["survived", *FEATURES]].dropna().copy()
    df["sex"] = (df["sex"] == "female").astype(int)

    X = df[FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = DecisionTreeClassifier(max_depth=4, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    print(f"Test accuracy: {accuracy_score(y_test, predictions):.3f}")
    print("Confusion matrix:")
    print(confusion_matrix(y_test, predictions))

    # Save both model and feature order to prevent column-order mistakes.
    joblib.dump(
        {"model": model, "features": FEATURES},
        "model.joblib"
    )
    print("Saved model.joblib successfully.")

if __name__ == "__main__":
    main()
